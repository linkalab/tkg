#!/bin/bash
wget https://github.com/RMLio/rmlmapper-java/releases/download/v4.10.1/rmlmapper-4.10.1.jar -O rmlmapper-4.10.1.jar
ln -s rmlmapper-4.10.1.jar rmlmapper.jar
